<?php
$id_telegram = "6848668447";
$id_botTele  = "6891442273:AAEyp8HWaFtvYCFiiy4efRSwppe6MbO8n3Y";
?>
